<ul class="navigation">
 <!--<li><a href="#" title="Menu" onclick="toggleMenu()">&#9776; Menu</a></li>-->

 <li><a href="#" title="Home">Home</a></li>
 <li><a href="#" title="Cannon">Cannon</a></li>
 <li><a href="#" title="Explosive">Explosive</a></li>
 <li><a href="#" title="Miscellaneous">Misc</a></li>
 <li><a href="#" title="Rocket">Rocket</a></li>
 <li><a href="#" title="Trap">Trap</a></li>
</ul>