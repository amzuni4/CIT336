<hr>
 <p>&copy; 2019 ACME &nbsp; | &nbsp; All Rights Reserved &nbsp; <span class="divider"> &nbsp;   | &nbsp; </span><date><?php echo date('1, d F Y') ?></date></p>
  <p><em>All images used are believed to be in "Fair Use." Please notify the author if any are not and they will be removed.</em></p>
  <p>Last Updated: <?php echo date('j F Y' , getlastmod()) ?></p>

