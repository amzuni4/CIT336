<!--<div class="account">

 <a href="" title="accMenu">
  <img class="fileIcon" src="images/site/account.gif" alt="fileIcon"/>
  <div class="ac">My account </div> </a>
</div>
<div class="logoArea">
 <img class="logo" src="images/site/logo.gif" alt="ACME Logo">
</div>-->

<div>
  <img class="logo" src="images/site/logo.gif" alt="ACME Logo">
  <div class="account">
    <a href="#"><img class="fileIcon" src="images/site/account.gif" alt="fileIcon"/>
     My account</a>
  </div>
</div>